package com.handrefill;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class HandRefillClient implements ClientModInitializer {

    // Totemin gelecegi slot: envanterin en ust sirasinin 5. slotu
    // (sol el slotunun tam altindaki slot). Envanter indexi 9-35 arasi ana envanter,
    // 9 + 4 = 13.
    private static final int TARGET_SLOT = 13;

    // Islemden sonra tekrar denemeden once beklenecek tick sayisi
    private static final int COOLDOWN_TICKS = 3;

    private static int cooldown = 0;

    // Mod acik mi? Ayarlar > Kontroller'deki tusla degisir, ekrana yazi cikmaz.
    private static boolean enabled = true;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        // Varsayilan tus K, Ayarlar > Kontroller > "Hand Refill" altindan degistirilebilir
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.handrefill.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.handrefill"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(HandRefillClient::onTick);
    }

    private static void onTick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
        }

        if (!enabled) return;
        if (client.player == null || client.interactionManager == null) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        // Sandik, craft masasi vb. baska bir ekran aciksa karisma.
        // Oyun icindeyken veya kendi envanterin aciksken calisir.
        if (client.currentScreen != null && !(client.currentScreen instanceof InventoryScreen)) {
            return;
        }

        // Imlecte esya tasiyorsan karisma
        if (!client.player.playerScreenHandler.getCursorStack().isEmpty()) return;

        PlayerInventory inv = client.player.getInventory();

        // Hedef slot dolu ise bir sey yapma
        if (!inv.getStack(TARGET_SLOT).isEmpty()) return;

        // Envanterde baska bir totem ara: once ana envanter (9-35), sonra hotbar (0-8)
        int totemIndex = -1;
        for (int i = 9; i < 36; i++) {
            if (i == TARGET_SLOT) continue;
            if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                totemIndex = i;
                break;
            }
        }
        if (totemIndex == -1) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    totemIndex = i;
                    break;
                }
            }
        }
        if (totemIndex == -1) return;

        // Oyuncu envanteri ekraninda slot numaralari:
        // 9-35 = ana envanter, 36-44 = hotbar
        int sourceScreenSlot = totemIndex < 9 ? 36 + totemIndex : totemIndex;
        int syncId = client.player.playerScreenHandler.syncId;

        // Totemi al, hedef slota birak
        client.interactionManager.clickSlot(syncId, sourceScreenSlot, 0, SlotActionType.PICKUP, client.player);
        client.interactionManager.clickSlot(syncId, TARGET_SLOT, 0, SlotActionType.PICKUP, client.player);

        cooldown = COOLDOWN_TICKS;
    }
}
